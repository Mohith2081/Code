package com.demotraining;

public class Dataset {

	private float distance;
	
	private float time;

	public float getDistance() {
		return distance;
	}

	public void setDistance(float distance) {
		this.distance = distance;
	}

	public float getTime() {
		return time;
	}

	public void setTime(float time) {
		this.time = time;
	}

	

	public Dataset() {
		// TODO Auto-generated constructor stub
	}

	
	
	
}
